Flies
by R-Zero

Version: 1.1

###########################

Changelog:

v1.1 PfP

- Fixed underwater flies bug, using fix from Patch for Purists.

v.1.1

-Fixed a collision error, thanks to RE4PER for noticing this.


v.1.0

-Initial release.


###########################

Description:

This plugins adds a visual effect to all vanilla flies sound emitters. Now everywhere you can hear flies buzzing, you'll be able to actually see fly swarms too.

###########################

Installation:

1. Unpack the Data Files folder of this archive to your game folder.
2. Activate the "Flies.ESP" plugin in the Data Files  menu of the game launcher.

###########################

Requirements:

Morrowind
Tribunal


