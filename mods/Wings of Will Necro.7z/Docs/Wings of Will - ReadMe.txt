﻿=============
Description
=============
In the base game, the levitation speed is based on the Speed attribute. This never made much sense to me. You can levitate faster by being a great runner? Now levitation is based on the Willpower attribute (just as the Alteration skill is) with other calculations remaining the same.

=============
Requirements
=============
The mod is based on MWSE Lua functionality and thus require the MWSE nightly﻿﻿.

=============
Compatibility
=============
The mod should be compatible with everything (assuming it doesn't interfere with the required MWSE). The only known exception are companion scripts which set up companion's Speed attribute based on the player's so they won't get lost behind. They will still work, but as the levitation speed is not based on the Speed attribute the speed will not match.

=============
Permissions
=============
You can do whatever you want with this mod.

=============
Changelog
=============
1.0 - Initial release
1.1 - The script now doesn't affect flying creatures.