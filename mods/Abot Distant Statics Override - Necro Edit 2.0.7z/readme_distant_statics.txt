===============================================================================
|                Abot's Distant Statics Overrides - Necro Edit                |
|                         A Morrowind Mod, Version 2.0                        |
|                                by Necrolesian                               |
===============================================================================

-------------
Description |
-------------

These files are my personal edited version of Abot's distant statics override
file. They replace Abot's file, and the one that ships with MGE XE. The purpose
of these files is to override how MGE XE treats certain objects when rendering
them in distant land.

There are a number of items that benefit from special handling for viewing as
distant statics. Some items shouldn't be shown at all because they're disabled
(like the chargen boat and the stuff on it) or because they're not supposed to
actually be visible. Some need to be hidden or have their mesh detail reduced
for performance reasons, while some should appear at a greater distance even
when they normally wouldn't. These files handle all that.

There are also a number of circumstances in which you would want to change what
gets rendered in distant land, depending on where you are in the game, and
these files allow for that too. For example, the ghostfence (the actual
forcefield, not the pylons) should appear in distant land before the main quest
is complete, but it should not appear afterward. The great house strongholds
should normally not appear in distant land (they would just disappear when you
got close enough). Instead, they should only be rendered once they've actually
been constructed in-game.

The way to handle this is to enable one or more additional, supplemental files
that override the main one. See the instructions section below for details on
how and when to do this.

Note that these files affect only what MGE XE renders in distant land. They
have no effect on what the game renders within standard Morrowind view
distance.

--------------
Known Issues |
--------------

There is one issue related to certain trees and rocks in Raven Rock, at the SE
location of the factor's estate. This issue applies only if you are *not* using
the mod Under Construction - that mod fixes the vanilla script error that
causes the problem.

Each of the three possible locations for the factor's estate in Raven Rock
contains trees and rocks that disappear after you select that location for your
estate. However, due to an error in a script, the trees/rocks at the SE
location will also disappear after construction of the estate is completed at
either of the other two locations.

The relevant factor's estate override files however keep these objects enabled
in distant land, as they should be. This means that, in vanilla Morrowind, if
you choose a location for your estate other than the SE one, after it's
complete and you've regenerated distant statics with the appropriate files
enabled, you might see these trees/rocks pop in and out of existence at the
distant land boundary.

To fix this issue, use the mod Under Construction, which fixes the script
responsible for it.

--------------
Installation |
--------------

Just dump the necro_distant_statics_override directory into your Morrowind\mge3
directory. It can actually go anywhere, but this is the most logical place for
it.

--------------
Requirements |
--------------

These files obviously require MGE XE to be of any use.

--------------
Instructions |
--------------

These files are enabled in MGE XE, on the distant statics page during distant
land generation.

To enable them, make sure the "use lists of statics overriding parameters set
above" checkbox is selected, and click "edit lists". Remove any other file
(such as any old version of my edited file, Abot's file, or the one that ships
with MGE XE) present. Then click "add" and select the file "00_main.ovr" and
any other appropriate files (see below for details). Then save the list and
generate distant statics.

The main file (00_main.ovr) should *always* be enabled. At the beginning of the
game, it is the only file that should be enabled. Later, on reaching certain
milestones, you'll want to enable one or more of the additional files to
override the main one - just regenerate distant statics again, removing or
adding override files as needed. (Tip: to reduce the time required to generate
distant statics, set distant texture reduction to "none".)

When you begin a new playthrough, you'll want to disable any override files you
had enabled on your last playthrough other than the main file, and regenerate
distant statics with only the main file active.

These files are divided into categories denoted by the number at the beginning
of the filename (01, 02, and so on). Files from multiple categories can be
active simultaneously. For example, if you've completed both the main quest and
the Bloodmoon main quest, and you've also completed stage 2 (but not stage 3)
of Great House stronghold construction, the following files should be enabled:

00_main.ovr
01_main_quest_complete.ovr
02_bm_main_quest_complete.ovr
05-4_strongholds_stage_2_complete.ovr

However, for categories with multiple files, no more than one file in each
category should ever be active at the same time. So, for example, there should
only ever be zero or one of the 05 (stronghold) files active at any given time.

The order of these supplemental files generally does not matter, except that
any supplemental files (01-08) must come after the main one. The main file
*must* come first, at the top of the override files list, so that any other
files can override it.

Below is a list of the files included, what they do, and instructions for when
they should be enabled:

00 (Main)
---------

The file 00_main.ovr should *always* be enabled, and should always come first,
at the top of the override files list. It contains the main list of overrides,
along with those for the objects affected by the supplemental files
corresponding to their proper state at the beginning of the game. At the
beginning of the game, this is the only file that should be enabled.

01 (Main Quest)
---------------

This file (01_main_quest_complete.ovr) should be enabled after completing the
(Vvardenfell) main quest, specifically after completing the quest "The Citadels
of the Sixth House". It disables the ghostfence (just the actual forcefield,
not the pylons) in distant land.

02 (Bloodmoon Main Quest)
-------------------------

The file 02_bm_main_quest_complete.ovr should be enabled after completing the
Bloodmoon main quest, specifically after completing the quest "Hircine's Hunt".
It replaces the intact version of the Mortrag Glacier with the broken,
shattered version that appears at this point in the game.

03 (Boethiah's Quest)
---------------------

These files relate to the daedric statue of Boethiah at Khartag Point, which
replaces the giant rock previously at that site. No more than one of these
files should ever be active at once.

03-1_boethiah_quest_in_progress.ovr: Enable this file once construction on the
- - - - - - - - - - - - - - - - - -  Boethiah statue *begins*. Specifically,
this occurs ten days *after* Duma gro-Lag tells you he'll begin work. You will
not receive a journal entry when construction actually begins.

This file just enables scaffolding and other objects around the rock.

03-2_boethiah_quest_complete.ovr: Enable this file once construction on the
- - - - - - - - - - - - - - - - - Boethiah statue *ends*. This occurs ten days
after construction begins, or 20 days after Duma gro-Lag tells you he'll begin
work. You will not receive a journal entry when construction ends.

This file disables the rock along with the scaffolding, and enables the statue.

04 (Firemoth)
-------------

If you're using the official plugin Siege at Firemoth, enable the file 04_
firemoth_complete.ovr after you've completed the associated quest. (If you're
not using the official plugin, you can ignore this file.) This file just
disables the two boats added by the plugin, which disappear after the quest is
complete.

05 (Great House Strongholds)
----------------------------

These files determine what will be rendered in distant land at the sites of the
three Great House strongholds. At the beginning of the game there will be
nothing at these locations, but as you progress through the stronghold quests
for your house, the strongholds will progress through multiple stages of
construction.

No more than one of these files should ever be active at the same time. Two of
these files should be skipped unless you're using the mod Under Construction
(which I recommend).

05-1_strongholds_stage_1_in_progress.ovr: Enable this file when construction
- - - - - - - - - - - - - - - - - - - - - first begins at your stronghold. This
happens five days after giving your stronghold quest giver the construction
contract and the other materials they need (a land deed for Hlaalu, gold for
Redoran, and two "strong souls" for Telvanni).

At this stage, for Hlaalu and Redoran, the main building has appeared but is
not yet accessible, and there is scaffolding and construction materials at the
site. For Telvanni, the very beginning of a mushroom tower appears.

05-2_strongholds_stage_1_complete.ovr: Enable this file when the first stage of
- - - - - - - - - - - - - - - - - - -  your stronghold is complete.
Specifically, this happens five days after checking in with the foreman, and
talking to your stronghold quest giver again.

At this stage, for Hlaalu and Redoran, the main building is now accessible, and
the construction materials are gone. For Telvanni, the tower is more developed,
but the interior is still not accessible.

05-3_strongholds_stage_2_in_progress.ovr: If you're *not* using the mod Under
- - - - - - - - - - - - - - - - - - - - - Construction, the game will skip this
phase, and this file should never be enabled. If you *are* using Under
Construction, this file should be enabled at the following milestones:

Hlaalu: Upon recruiting a miner, and talking to Dondos again.
Redoran: Upon hiring guards, and talking to Galsa again.
Telvanni: Upon giving Llunela the Dwemer schematics and 5000 gold.

At this stage, assuming you're using Under Construction, additional buildings
(inaccessible for now) and construction materials appear at the Hlaalu and
Redoran strongholds. The Telvanni stronghold's tower is yet more developed,
with additional dwellings, but still no interiors are accessible.

05-4_strongholds_stage_2_complete.ovr: Enable this file when the second stage
- - - - - - - - - - - - - - - - - - -  of your stronghold is complete, which
happens five days *after* the above milestones for "stage 2 in progress".

For Hlaalu and Redoran, the new buildings are now accessible and any
scaffolding and construction materials from the in-progress phase are gone. For
Telvanni, the tower is finally developed enough for (part of) the interior to
be accessible, along with two homes.

05-5_strongholds_stage_3_in_progress.ovr: This file, like the stage 2 in
- - - - - - - - - - - - - - - - - - - - - progress file above, should be
skipped if you're not using the mod Under Construction. If you are using that
mod, this file should be enabled at the following times:

Hlaalu: Upon killing the head bandit at Zainsipilu and talking to Dondos again.
Redoran: Upon recruiting wives, and talking to Galsa again.
Telvanni: Upon showing Llunela the book Secrets of Dwemer Animunculi.

At this stage (with Under Construction), more buildings (again inaccessible for
now) appear at the Hlaalu and Redoran strongholds, along with scaffolding and
construction materials. At the Telvanni stronghold, the tower has reached
another intermediate stage, and two new dwellings have appeared, but no new
interiors are accessible.

05-6_strongholds_stage_3_complete.ovr: This file should be enabled when the
- - - - - - - - - - - - - - - - - - -  final stage of stronghold construction
is complete. This happens five days *after* the above milestones for "stage 3
in progress".

The strongholds have reached their final state, with all buildings and
interiors accessible.

06 (Raven Rock Main)
--------------------

The colony at Raven Rock on Solstheim is the most complicated case when using
these files. There are three separate categories of files related to Raven
Rock. These 06 files are for the main sequence of colony progression, including
the factor's estate at the end. The 07 files are for the smithy or trader's
shop (since there are two options, and construction continues afterward, a
separate category is required to avoid unneeded complexity). There's also a
special case addressed by the 08 file.

Like with the other categories with multiple files, no more than one of these
06 files should be active at any given time. If you pass over multiple stages
without updating distant statics with the new file (due to how quickly Raven
Rock construction can progress), then just skip files as needed and enable the
file corresponding to the current construction stage.

06-01_ravenrock_stage_1_in_progress.ovr: Enable this file at the very beginning
- - - - - - - - - - - - - - - - - - - -  of Raven Rock construction, upon
completing the quest "Establish the Mine".

06-02_ravenrock_mine_entrance_complete.ovr: Enable this file three days after
- - - - - - - - - - - - - - - - - - - - - - finishing "Establish the Mine".

06-03_ravenrock_stage_1_complete.ovr: Enable three days after finishing the
- - - - - - - - - - - - - - - - - - - quest "A Blocked Door".

06-04_missing_supply_ship.ovr: Activate upon *beginning* the quest "Missing
- - - - - - - - - - - - - - -  Supply Ship". This does not actually affect
anything at the colony itself, but enables the wrecked supply ship in distant
land.

Note that, between this point and when you enable the next 06 file, you will
also complete construction of the smithy or trader's shop addressed by the 07
files. One of the two "complete" 07 files will also be enabled for each of the
subsequent 06 file updates.

06-05_ravenrock_stage_2_complete.ovr: Enable this file three days after
- - - - - - - - - - - - - - - - - - - finishing the quest "To Catch a Thief"
(for Falco) or "Aiding and Abetting" (for Carnius).

06-06_ravenrock_stage_3_in_progress.ovr: Enable this file immediately upon
- - - - - - - - - - - - - - - - - - - -  finishing the quest "Hiring Guards".

06-07_ravenrock_stage_3_complete.ovr: Enable three days *after* finishing
- - - - - - - - - - - - - - - - - - - "Hiring Guards".

06-08_ravenrock_stage_4_in_progress.ovr: This file should be enabled at the
- - - - - - - - - - - - - - - - - - - -  following milestones:

Falco side: Upon receiving the silver longswords from Constans Atrius during
the quest "Under Siege".

Carnius side: Upon *beginning* the quest "Drastic Measures".

06-09_ravenrock_stage_4_complete.ovr: Activate this file three days after
- - - - - - - - - - - - - - - - - - - finishing "Under Siege" (for Falco) or
"Drastic Measures" (for Carnius).

06-10_ravenrock_factor_SW_in_progress.ovr: Only one of the following three
- - - - - - - - - - - - - - - - - - - - -  files should ever be enabled,
depending on which location you choose for the factor's estate. This file
should be enabled when construction begins on the estate at the SW location
(which occurs one day *after* choosing it).

06-11_ravenrock_factor_NE_in_progress.ovr: Enable one day after choosing the NE
- - - - - - - - - - - - - - - - - - - - -  location.

06-12_ravenrock_factor_SE_in_progress.ovr: Enable one day after choosing the SE
- - - - - - - - - - - - - - - - - - - - -  location.

06-13_ravenrock_factor_SW_complete.ovr: Again, only one of these next three
- - - - - - - - - - - - - - - - - - - - files should ever be enabled. This one
should be activated when construction on the estate is complete, three days
after choosing the SW location.

06-14_ravenrock_factor_NE_complete.ovr: Enable three days after choosing the NE
- - - - - - - - - - - - - - - - - - - - location.

06-15_ravenrock_factor_SE_complete.ovr: Enable three days after choosing the SE
- - - - - - - - - - - - - - - - - - - - location.

07 (Raven Rock Service)
-----------------------

These files relate to the smithy or trader's shop that will be built as part of
the Raven Rock questline. The shop will be begun and completed after stage 1 of
colony construction is complete and the missing supply ship is activated, but
before stage 2 is complete.

No more than one of these 07 files should ever be active at once, but it should
be enabled *in addition to* whichever 06 file you have enabled. You'll enable
either the smithy in progress then the smithy complete files, or the trader in
progress then the trader complete files.

07-1_rr_service_smithy_in_progress.ovr: Enable when construction on the smithy
- - - - - - - - - - - - - - - - - - - - begins, which happens one day after you
choose to build a smithy.

07-2_rr_service_trader_in_progress.ovr: Enable one day after choosing to build
- - - - - - - - - - - - - - - - - - - - a trader's shop.

07-3_rr_service_smithy_complete.ovr: Enable this file after reporting to
- - - - - - - - - - - - - - - - - -  Carnius that the smithy is almost done
(which you can do two days after choosing to build a smithy).

07-4_rr_service_trader_complete.ovr: Enable this file after reporting to
- - - - - - - - - - - - - - - - - -  Carnius that the trader's shop is almost
done (which you can do two days after choosing to build a trader's shop).

08 (Baro's Ship)
----------------

The file 08_rr_special_baro_ship.ovr addresses a special case related to the
colony. As soon as either the smithy or trader's shop has been completed, a new
ship appears at the Raven Rock pier; this new ship will disappear once the next
Raven Rock quest is complete.

Adding this ship to the 07 files would require two additional files, one for
the smithy and one for the trader; making this one-off file was the simplest
solution.

This file should be enabled when the smithy or trader's shop is complete (i.e.
at the same time that you activate the 07-3 or 07-4 file).

You should *disable* this file upon completing the quest "Supply Route
Problems". This is the only override file that is ever removed from the list in
the middle of a playthrough without being replaced with another one.

-----------------
Recommendations |
-----------------

I recommend using the mod Under Construction with these files. That mod
implements intermediate construction phases for the Great House strongholds
corresponding to the "in progress" files for stages 2 and 3. These intermediate
phases were created by Bethesda, just not fully implemented.

Under Construction also fixes an error in one of the Raven Rock scripts that
caused certain trees/rocks at the SE factor's estate location to be disabled
when they shouldn't be. The factor's estate files treat these objects as though
the script is fixed.

-----------------
Version History |
-----------------

Version 2.0 - 2021-10-06
   - There are now multiple supplemental files intended to override the main
        one. This greatly simplifies the process of updating distant statics
        upon reaching certain milestones - no need to manually comment and
        uncomment lines.
   - Each stage of Great House stronghold and Raven Rock construction has its
        own separate file, unlike before when it was all or nothing for both.
   - Greatly improved the lists of objects enabled/disabled for the strongholds
        and Raven Rock. They should now be exhaustive.

Version 1.0
   - Initial release.

---------
Credits |
---------

These files are based on Abot's original distant statics override file. Most of
this is still Abot's work, except for the stronghold and Raven Rock overrides.

---------
Contact |
---------

If you have any comments or suggestions, you can contact me on the Nexus, find
me on Discord as Necrolesian#9692, or email me at necrolesian@riseup.net.

-------
Usage |
-------

If you use these files in your own work, please credit Abot, without whose hard
work these files would not exist.