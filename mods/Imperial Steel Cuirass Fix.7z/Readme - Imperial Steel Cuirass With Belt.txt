Name: Imperial Steel Cuirass With Belt
Version: 1.0
Date: 12/12/2020
Category: Models and Textures
Author: Alaisiagae & Quorn

Description
===========
Adds the missing belt to the male Imperial Steel Cuirass and replaces the icon.

Details
=======
This mod includes the Imperial Steel Cuirass Fix by quorn. The Imperial cuirass was meant to have this nifty belt, but the mesh was not skinned properly, so you don't see this in-game. The icon for the Imperial Steel cuirass has been updated by Alaisiagae to show the belt.


Install
=======
1. Extract the files to a temporary location.
2. Examine the folder structure and make corrections where necessary.
3. Copy files to (install folder)\Morrowind\Data Files\
4. Start Morrowind and play.

Uninstall
=========
Delete the following:

Icons\a\tx_imperial_curaiss.dds

Meshes\a\a_imperial_skins.nif


Incompatibility
===============
This mod will conflict with another mod that changes the same meshes and icons listed in the "Uninstall" section of this readme.

This mod will NOT conflict with a texture replacer.

This mod will not conflict with a mod that changes the armor stats/properties of the armor pieces replaced by this mod.


Known Issues or Bugs
====================
If there are any bugs or issues, please let me know.


Credits
=======
Thanks to quorn for creating the Imperial Steel Cuirass Fix mod.
Thanks to Alaisiagae for creating the updated Imperial Steel Cuirass icon.