*****************************************************************

The Elder Scrolls III
MORROWIND: 
Complete Armor Joints
By Kahkahra



  
*****************************************************************

Index:
1. Installation
2. Playing the Plugin
3. Save Games
4. Known Issues/Conflicts
5. Credits

*****************************************************************

    1. INSTALLING THE PLUGIN

*****************************************************************

To install the plugin, unzip the files into the Morrowind/Data Files
directory. Or do it the best way and drop the files into their correct file directory yourself!

*****************************************************************

    2. PLAYING THE PLUGIN

*****************************************************************
This plugin adds knee and forearm pieces to many different armor sets. The bonemold, orcish/etc armors already
had these, they were just unused. With the armor that didn't have the joint meshes I simply used ones that were matching color.
It makes for a much more uniform cosmetic effect. FYI the forearm joint for the Dwemer pauldrons is bugged, but if you
put the forearm joint in the dwemer bracers it makes for a bugless work-around.


*****************************************************************

    3. Save Games

*****************************************************************

This plugin should not invalidate your old saved games.

**Note: As a rule, you should backup all your saves before using this or any
other plugin, as a precaution against any strange error you might encounter.


*****************************************************************

    4. Known Issues/Conflicts

*****************************************************************

Maybe a few with mods that alter the same pauldrons and greaves that I did. But don't count on it.

If you encounter any problems leave me a message at http://planetelderscrolls.gamespy.com/View.php?view=Mods.Detail&id=92822&id=6358
and I will fix it ASAP!

*****************************************************************

Enjoy!