Putting Power in Willpower 2.0 (Necro Edit)
uploaded by Sigourn

This is an edit of R-Zero's Putting Power in Willpower 2.0.
I've implemented the edits suggested by Necrolesian in his modding guide and for users to install when following
my modding guide.

The following changes have been implemented:

* Fixed a target's high fatigue potentially making things worse instead of better when the target's willpower is lower than the caster's.
* Fixed being unable to resist effects without a magnitude, like Paralysis.
* Resist multiplier changed to 5 (from 10).
* "Allow negative resistance bonuses" set to on by default.
* "Allow magic absorption for high resistances" set to off by default.