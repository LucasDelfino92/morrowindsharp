What Are My Attributes? 1.0.1 (Necro Edit)
uploaded by Sigourn

This is an edit of RingComics' What Are My Attributes? 1.0.1.
I've implemented the edits suggested by Necrolesian in his modding guide and for users to install when following
my modding guide.

The following changes have been implemented:

* "Attributes", "Description" and "Specials" labels are not brighter than the other labels.
* Text spacing between icons and text increased.
